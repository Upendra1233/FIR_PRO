# Real-Time Data HTML Project

This project provides a web-based interface for displaying and downloading real-time data related to calls. Users can view various fields of data in a table format and select specific fields for download in CSV format.

## Project Structure

```
real-time-data-html
├── src
│   └── real_time_data.html  # HTML file containing the real-time data display
├── README.md                 # Documentation for the project
```

## Features

- **Dynamic Data Display**: The HTML page displays real-time data in a structured table format.
- **Field Selection for Download**: Users can select which fields to include in the downloaded CSV file. All fields are selected by default.
- **CSV Download**: The selected fields can be downloaded in CSV format for further analysis or reporting.

## Setup Instructions

1. **Clone the Repository**: 
   ```bash
   git clone <repository-url>
   cd real-time-data-html
   ```

2. **Open the HTML File**: 
   Open `src/real_time_data.html` in a web browser to view the real-time data interface.

3. **Select Fields**: 
   Use the dropdown to select or deselect fields you wish to download.

4. **Download Data**: 
   Click the download button to download the selected fields in CSV format.

## Usage

- The table will automatically populate with real-time data.
- Use the field selection dropdown to customize your download.
- Ensure that you have a stable internet connection for real-time updates.

## Contributing

Contributions are welcome! Please submit a pull request or open an issue for any enhancements or bug fixes.

## License

This project is licensed under the MIT License. See the LICENSE file for more details.