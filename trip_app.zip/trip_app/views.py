import os
import datetime
from django.shortcuts import render
from django.conf import settings
from django.core.files.storage import FileSystemStorage
import pandas as pd

# small helper that runs your processing and writes Excel output
def process_csv_to_excel(input_csv_path: str, output_xlsx_path: str):
    a = pd.read_csv(input_csv_path)
    a['Event Time'] = pd.to_datetime(a.get('Event Time'), errors='coerce')
    a['Ingestion Timestamp'] = pd.to_datetime(a.get('Ingestion Timestamp'), errors='coerce')

    # assign trip numbers
    trip_num = 0
    in_trip = False
    trip_series = []
    for msg in a["Message Type"]:
        if msg == "TRIP_START":
            trip_num += 1
            in_trip = True
            trip_series.append(trip_num)
        elif msg == "TRIP_END":
            trip_series.append(trip_num)
            in_trip = False
        else:
            trip_series.append(trip_num if in_trip else None)
    a["Trip Number"] = trip_series

    a["Time Diff (sec)"] = (a["Ingestion Timestamp"] - a["Event Time"]).dt.total_seconds()

    def time_category(seconds):
        if pd.isna(seconds):
            return None
        if seconds < 5 * 60:
            return "0-5Mins"
        if seconds < 15 * 60:
            return "5-15Mins"
        if seconds < 30 * 60:
            return "15-30Mins"
        if seconds < 60 * 60:
            return "30-1Hr"
        if seconds < 3 * 60 * 60:
            return "1-3Hrs"
        if seconds < 6 * 60 * 60:
            return "3-6Hrs"
        return ">6Hrs"

    a["Time Range"] = a["Time Diff (sec)"].apply(time_category)

    periodic = a[a["Message Type"] == "EDC_BS6_PERIODIC"]

    summary = []
    for (trip, time_cat), group in periodic.groupby(["Trip Number", "Time Range"]):
        if pd.isna(trip) or pd.isna(time_cat):
            continue
        group = group.sort_values("Event Time")

        non_zero = group[group["Odometer"].notna() & (group["Odometer"] != 0)]
        start = non_zero.iloc[0] if not non_zero.empty else group.iloc[0]
        end = non_zero.iloc[-1] if not non_zero.empty else group.iloc[-1]

        # try fill addresses
        if not start.get("Address") or pd.isna(start.get("Address")):
            addr_candidates = group[group["Address"].notna() & (group["Address"] != "")]
            if not addr_candidates.empty:
                start = addr_candidates.iloc[0]
        if not end.get("Address") or pd.isna(end.get("Address")):
            addr_candidates = group[group["Address"].notna() & (group["Address"] != "")]
            if not addr_candidates.empty:
                end = addr_candidates.iloc[-1]

        start_ingest = start.get("Ingestion Timestamp")
        end_ingest = end.get("Ingestion Timestamp")
        total_odo = None
        try:
            total_odo = end.get("Odometer") - start.get("Odometer")
        except Exception:
            total_odo = None

        if pd.notna(start_ingest) and pd.notna(end_ingest):
            td = end_ingest - start_ingest
            time_taken = str(td)
            time_taken_hours = td.total_seconds() / 3600
        else:
            time_taken = None
            time_taken_hours = None

        full_group = a[(a["Trip Number"] == trip) & (a["Time Range"] == time_cat)]
        msg_counts = full_group["Message Type"].value_counts().to_dict()

        data = {
            "Trip": f"Trip {int(trip)}",
            "Time Range": time_cat,
            "Start Time (Event)": start.get("Event Time"),
            "End Time (Event)": end.get("Event Time"),
            "Start Odo": start.get("Odometer"),
            "End Odo": end.get("Odometer"),
            "Total Odo": total_odo,
            "Start Location (Address)": start.get("Address"),
            "End Location (Address)": end.get("Address"),
            "Ingestion Timestamp Start": start_ingest,
            "Ingestion Timestamp End": end_ingest,
            "Time taken to post (hh:mm:ss)": time_taken,
            "Time taken to post (hours)": time_taken_hours,
            "Start Latitude": start.get("Latitude"),
            "Start Longitude": start.get("Longitude"),
            "End Latitude": end.get("Latitude"),
            "End Longitude": end.get("Longitude")
        }

        for msg in [
            "HARSH_ACCELERATION_START",
            "HARSH_ACCELERATION_END",
            "HARSH_BREAKING_START",
            "HARSH_BREAKING_END",
            "EDC_BS6_PERIODIC",
            "Ignition ON",
            "Ignition OFF",
            "HEARTBEAT_MESSAGE"
        ]:
            data[msg] = msg_counts.get(msg, 0)

        summary.append(data)

    summary_df = pd.DataFrame(summary)
    if not summary_df.empty:
        summary_df["Trip_TimeRange"] = summary_df["Trip"] + " - " + summary_df["Time Range"]
        pivot_df = summary_df.drop(columns=["Trip", "Time Range"]).set_index("Trip_TimeRange").T
    else:
        pivot_df = pd.DataFrame()

    # write both sheets
    with pd.ExcelWriter(output_xlsx_path, engine="openpyxl") as writer:
        pivot_df.to_excel(writer, sheet_name="Summary_Report")
        a.to_excel(writer, sheet_name="Raw_Data", index=False)


def upload_file(request):
    download_url = None
    error = None
    if request.method == "POST" and request.FILES.get("csv_file"):
        f = request.FILES["csv_file"]
        uploads_dir = os.path.join(settings.MEDIA_ROOT, "uploads")
        os.makedirs(uploads_dir, exist_ok=True)
        fs = FileSystemStorage(location=uploads_dir, base_url=os.path.join(settings.MEDIA_URL, "uploads/"))
        saved_name = fs.save(f.name, f)
        input_path = fs.path(saved_name)

        outputs_dir = os.path.join(settings.MEDIA_ROOT, "outputs")
        os.makedirs(outputs_dir, exist_ok=True)
        out_name = f"Trip_Summary_Report_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}.xlsx"
        out_path = os.path.join(outputs_dir, out_name)

        try:
            process_csv_to_excel(input_path, out_path)
            # construct URL relative to MEDIA_URL (serving MEDIA in dev required)
            download_url = settings.MEDIA_URL.rstrip("/") + "/outputs/" + out_name
        except Exception as e:
            error = str(e)

    return render(request, "trip_app/upload.html", {"download_url": download_url, "error": error})