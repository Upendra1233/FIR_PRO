from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse, HttpResponse
from django.utils.timezone import now
from django.core.mail import EmailMessage
from django.urls import reverse
from django.template.loader import render_to_string
from .models import AIS140Request
from .forms import ManagerForm, PartBForm
import logging
import csv
from datetime import datetime
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.utils.timezone import localtime
import datetime
import pytz
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET
import json

logger = logging.getLogger(__name__)

DATETIME_FORMAT = "%d-%m-%Y %H:%M:%S"
IST = pytz.timezone('Asia/Kolkata')

def to_ist(dt):
    if not dt:
        return ''
    if isinstance(dt, datetime.datetime):
        if dt.tzinfo is None:
            dt = pytz.utc.localize(dt)
        dt = dt.astimezone(IST)
        return dt.strftime(DATETIME_FORMAT)
    elif isinstance(dt, datetime.date):
        dt = datetime.datetime.combine(dt, datetime.time.min)
        dt = IST.localize(dt)
        return dt.strftime(DATETIME_FORMAT)
    return dt

def part_a_form(request):
    if request.method == 'POST':
        try:
            form = ManagerForm(request.POST, request.FILES)
            if form.is_valid():
                entry.date_of_request = now()  # Set the current date and time

                entry = form.save(commit=False)  # Don't save to the database yet
                entry.save()  # Save the object to the database

                # Generate Part B URL
                part_b_url = request.build_absolute_uri(reverse('part_b_form', args=[entry.id]))

                # Prepare email details
                subject = f"AIS140 Certification Request : {entry.unique_id}"
                html_message = render_to_string('emails/part_a_email.html', {
                    'entry': entry,
                    'part_b_url': part_b_url,
                    'site_domain': request.build_absolute_uri('/')[:-1],  # Get the site domain
                })

                recipient_list = [entry.assigned_engineer_email]  # Replace with the actual customer email field
                cc_list = ['sales@danlawtech.com', "dilipkumarn@danlawtech.com","narendrareddyg@danlawtech.com","rajendrans@danlawtech.com"]  # Replace with actual manager and HOD email fields

                # Send email
                email = EmailMessage(
                    subject=subject,
                    body=html_message,
                    to=recipient_list,
                    cc=cc_list
                )
                email.content_subtype = 'html'  # Specify the email content type as HTML
                email.send()

                # Redirect to Part A form
                return redirect('part_a_form')
            else:
                logger.error(f"Form errors: {form.errors}")
        except Exception as e:
            logger.error(f"Unexpected error in part_a_form: {e}")
            return redirect('part_a_form')
    else:
        form = ManagerForm()
    return render(request, 'AIS140_FLOW/part_a_form.html', {'form': form})


def part_b_form(request, id):
    # Fetch the entry for Part-B
    entry = get_object_or_404(AIS140Request, id=id)

    # Fetch Part-A data
    part_a_data = {
        'date_of_request': entry.date_of_request,
        'requested_by': entry.requested_by,
        'requested_name': entry.requested_name,
        'requested_phone_number': entry.requested_phone_number,
        'device_mode': entry.device_mode,
        'request_type': entry.request_type,
        'category': entry.category,
        'assigned_to': entry.assigned_to,
        'user_id': entry.user_id,
        'state': entry.state,
        'vin_no': entry.vin_no,
        'engine': entry.engine,
        'psn': entry.psn,
        'vehicle_no': entry.vehicle_no,
        'vehicle_model': entry.vehicle_model,
        'customer_name': entry.customer_name,
        'customer_phone': entry.customer_phone,
        'pan_card': entry.pan_card,
        'aadhar_card': entry.aadhar_card,
        'manufacturing_year': entry.manufacturing_year,
        'rto_name': entry.rto_name,
        'rto_code': entry.rto_code,
        'dealer_name': entry.dealer_name,
        'dealer_code': entry.dealer_code,
        'ao_name': entry.ao_name,
        'ro': entry.ro,
        'zone': entry.zone,
        'remarks': entry.remarks,
    }

    # Determine if the form should be read-only
    is_read_only = entry.completion_status  in ["Permanent", "Temp + Perm","Temporary","Cancelled","Reject","Third Party Device-Rejected"]

    if request.method == 'POST' and not is_read_only:
        form = PartBForm(request.POST, request.FILES, instance=entry)  # Include request.FILES for file uploads
        if form.is_valid():
            cleaned = form.cleaned_data
            instance = form.save(commit=False)
            # set closure timestamps server-side (use cleaned_data, not form.<field>)
            if cleaned.get('d1') and not getattr(instance, 'D1_closure', None):
                instance.D1_closure = now()
            if cleaned.get('d2') and not getattr(instance, 'D2_closure', None):
                instance.D2_closure = now()
            instance.save()
            entry = instance
            # fixed precedence and consistent field names; only send Show Stopper when either d1/d2 present and entry not closed
            if (getattr(entry, 'd1', None) is not None or getattr(entry, 'd2', None) is not None) and (entry.completion_status == "Pending" or entry.completion_status=="Hold") :
                
                try:
                    subject = f"AIS140 Certificate Generation -Show Stopper  {entry.unique_id} on {entry.vin_no}"
                    html_message = render_to_string('emails/customer_update.html', {
                        'entry': entry,
                        'site_domain': request.build_absolute_uri('/')[:-1],  # Get the site domain
                    })
                    recipient_list_1 = ["KRY_arunkumar@ashokleyland.com",entry.assigned_engineer_email,entry.mail_to_customer,entry.requested_name,entry.TSM_mail,entry.Dealer_mail]  # Mail with TSM, CUSTOMER,ENGINEER, ARUN DEFAULT
                    cc_list_1 = ["sales@danlawtech.com","rajendran@danlawtech.com"]
                    email=EmailMessage(
                        subject=subject,
                        body =html_message,
                        to=recipient_list_1,
                        cc=cc_list_1
                    )
                    email.content_subtype = 'html'  # Specify the email content type as HTML
                    email.send()
                    logger.info(f"Email sent to manager for Part-B form update (Request ID: {entry.id})")
                except Exception as e:
                    logger.error(f"Failed to send email for Part-B form update (Request ID: {entry.id}): {e}")
            # Check if the form is marked as closed
            if entry.completion_status in ["Permanent", "Temp + Perm","Temporary","Cancelled","Reject","Third Party Device-Rejected"]:
                try:
                    # Prepare email details
                    subject = f"AIS140 Request Completed :  {entry.unique_id}"
                    html_message = render_to_string('emails/part_b_closed_email.html', {
                        'entry': entry,
                        'site_domain': request.build_absolute_uri('/')[:-1],  # Get the site domain
                    })

                    recipient_list = [entry.assigned_engineer_email,entry.mail_to_customer,entry.requested_name]  # Replace with the manager's email
                    cc_list = ['sales@danlawtech.com',"narendrareddyg@danlawtech.com","rajendrans@danlawtech.com"]  # Replace with additional recipients if needed

                    # Create the email
                    email = EmailMessage(
                        subject=subject,
                        body=html_message,
                        to=recipient_list,
                        cc=cc_list
                    )
                    email.content_subtype = 'html'  # Specify the email content type as HTML

                    # Attach the uploaded file if it exists
                    if entry.upload_certificate_in_ialert:
                        email.attach_file(entry.upload_certificate_in_ialert.path)
                    # Attach the uploaded file if it exists
                    if entry.upload_certificate_in_ialert_01:
                        email.attach_file(entry.upload_certificate_in_ialert_01.path)
                    # Attach the uploaded file if it exists
                    if entry.upload_certificate_in_ialert_02:
                        email.attach_file(entry.upload_certificate_in_ialert_02.path)

                    # Send the email
                    email.send()
                    logger.info(f"Email sent to manager for closed Part-B form (Request ID: {entry.id})")
                except Exception as e:
                    logger.error(f"Failed to send email for closed Part-B form (Request ID: {entry.id}): {e}")

            return redirect('part_b_form', id=entry.id)
        else:
            logger.error(f"Part B Form errors: {form.errors}")
    else:
        form = PartBForm(instance=entry)

    return render(request, 'AIS140_FLOW/part_b_form.html', {
        'form': form,
        'part_a_data': part_a_data,
        'is_read_only': is_read_only,
    })


def success_page(request):
    return render(request, 'AIS140_FLOW/success.html')



def download_part_b_csv(request):
    # Prepare filename
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f'AIS140_Data_{timestamp}.csv'
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'

    # Mapping: CSV Header -> Model Field
    field_map = {
        'Unique ID': 'unique_id',
        'Date of Request': 'date_of_request',
        'Requested By': 'requested_by',
        'Requestor Name': 'requested_name',
        'Requestor Phone Number': 'requested_phone_number',
        'State': 'state',
        'Chassis No': 'vin_no',
        'Engine No': 'engine',
        'PSN No': 'psn',
        'Device Model': 'device_mode',
        'ICICID No': 'icicid_no',
        'IMEI No': 'imei_no', 
        'D1 Remarks': 'd1',
        'D1 Engineer': 'D1_engineer',
        'D1 Closure Timestamp': 'D1_closure',
        'D2 Remarks': 'd2',
        'D2 Engineer': 'D2_engineer',
        'D2 Closure Timestamp': 'D2_closure',   
        'Completion Status': 'completion_status',
        'Completion Date': 'completion_date',   
        'Request Type': 'request_type',
        'Vehicle Regn No': 'vehicle_no',
        'Vehicle Model': 'vehicle_model',
        'Customer Name': 'customer_name',
        'Customer Phone No': 'customer_phone',

        'RTO Name': 'rto_name',
        'RTO Code': 'rto_code',
        'Dealer Name': 'dealer_name',

        'Zone': 'zone',
        'Remarks': 'remarks',
        'Cert. Generation Assigned To': 'assigned_engineer_email',
        'User ID': 'user_id',

        'Temporary Certificate Required': 'temp_cert_reqd',
        'Temporary Certificate Date': 'temp_cert_date',
        'Permanent Certificate Date': 'permanent_cert_date',
#        'Responsibility': 'responsibility',

        'Total TAT': 'total_tat',
        'Temporary certificate': 'upload_certificate_in_ialert',
        'Permanent certificate': 'upload_certificate_in_ialert_01',
        'Vahan Certificate': 'upload_certificate_in_ialert_02',
        'Mail to Customer': 'mail_to_customer',
        'Mail to Dealer': 'Dealer_mail',

        'Mail to TSM': 'TSM_mail',
        'Upload Certificate in Danlaw Server': 'upload_certificate_in_danlaw_server',
        'Completion Start Date': 'certification_start_date',
        'Completion End Date': 'certification_end_date',
    }

    # Get selected columns from GET (if none, use all)
    columns = request.GET.get('columns', '').split(',')
    if columns == [''] or not columns:
        fieldnames = list(field_map.keys())
    else:
        # Only include valid headers
        fieldnames = [col for col in columns if col in field_map]

    # Filtering logic (apply your filters here, example below)
    queryset = AIS140Request.objects.all()
    if request.GET.get('state'):
        queryset = queryset.filter(state=request.GET['state'])
    if request.GET.get('chassis_no'):
        queryset = queryset.filter(vin_no__icontains=request.GET['chassis_no'])
    if request.GET.get('psn_no'):
        queryset = queryset.filter(psn__icontains=request.GET['psn_no'])
    if request.GET.get('customer_name'):
        queryset = queryset.filter(customer_name__icontains=request.GET['customer_name'])
    if request.GET.get('assigned_engineer_email'):
        queryset = queryset.filter(assigned_engineer_email=request.GET['assigned_engineer_email'])
    if request.GET.get('completion_date_from'):
        queryset = queryset.filter(completion_date__gte=request.GET['completion_date_from'])
    if request.GET.get('completion_date_to'):
        queryset = queryset.filter(completion_date__lte=request.GET['completion_date_to'])
    if request.GET.get('category'):
        queryset = queryset.filter(category=request.GET['category'])
    if request.GET.get('date_of_request_from'):
        queryset = queryset.filter(date_of_request__gte=request.GET['date_of_request_from'])
    if request.GET.get('date_of_request_to'):
        queryset = queryset.filter(date_of_request__lte=request.GET['date_of_request_to'])
    if request.GET.get('unique_id'):
        queryset = queryset.filter(unique_id__icontains=request.GET['unique_id'])
    if request.GET.get('completion_status'):
        queryset = queryset.filter(completion_status=request.GET['completion_status'])

    # Write CSV
    writer = csv.DictWriter(response, fieldnames=fieldnames)
    writer.writeheader()
    for entry in queryset:
        row = []
        for col in fieldnames:
            value = getattr(entry, field_map[col], '')
            # Convert all datetime/date fields to IST
            if isinstance(value, datetime.datetime) or isinstance(value, datetime.date):
                value = to_ist(value)
            elif isinstance(value, datetime.time):
                value = value.strftime("%H:%M:%S")
            row.append(value)
        writer.writerow(dict(zip(fieldnames, row)))
    return response
def real_time_page(request):
    completion_status = request.GET.getlist('completion_status')
    assigned_engineer_email = request.GET.get('assigned_engineer_email', '')
    state = request.GET.get('state', '')
    chassis_no = request.GET.get('chassis_no', '')
    psn_no = request.GET.get('psn_no', '')
    customer_name = request.GET.get('customer_name', '')
    completion_date_from = request.GET.get('completion_date_from', '')
    completion_date_to = request.GET.get('completion_date_to', '')
    category = request.GET.get('category', '')
    date_of_request_from = request.GET.get('date_of_request_from', '')
    date_of_request_to = request.GET.get('date_of_request_to', '')
    unique_id = request.GET.get('unique_id', '')
    page = int(request.GET.get('page', 1))

    entries = AIS140Request.objects.all()
    if completion_status:
        entries = entries.filter(completion_status__in=completion_status)
    if assigned_engineer_email:
        entries = entries.filter(assigned_engineer_email=assigned_engineer_email)
    if state:
        entries = entries.filter(state__icontains=state)
    if chassis_no:
        entries = entries.filter(vin_no__icontains=chassis_no)
    if psn_no:
        entries = entries.filter(psn__icontains=psn_no)
    if customer_name:
        entries = entries.filter(customer_name__icontains=customer_name)
    if completion_date_from:
        entries = entries.filter(completion_date__gte=completion_date_from)
    if completion_date_to:
        entries = entries.filter(completion_date__lte=completion_date_to)
    if category:
        entries = entries.filter(category__icontains=category)
    if date_of_request_from:
        entries = entries.filter(date_of_request__gte=date_of_request_from)
    if date_of_request_to:
        entries = entries.filter(date_of_request__lte=date_of_request_to)
    if unique_id:
        entries = entries.filter(unique_id__icontains=unique_id)

    entries = entries.order_by('-date_of_request')

    # Pagination
    paginator = Paginator(entries, 25)
    try:
        paged_entries = paginator.page(page)
    except PageNotAnInteger:
        paged_entries = paginator.page(1)
    except EmptyPage:
        paged_entries = paginator.page(paginator.num_pages)

    entry_list = []
    for entry in paged_entries:
        sw_sch_date = entry.sw_sch_date
        completion_date = entry.completion_date
        total_tat = ''
        if sw_sch_date and completion_date:
            try:
                if isinstance(sw_sch_date, str):                                                   
                    sw_sch_date = datetime.fromisoformat(sw_sch_date)
                if isinstance(completion_date, str):
                    completion_date = datetime.fromisoformat(completion_date)
                diff = completion_date - sw_sch_date
                total_seconds = int(diff.total_seconds())
                hours = total_seconds // 3600
                minutes = (total_seconds % 3600) // 60
                seconds = total_seconds % 60
                total_tat = f"{hours:02}:{minutes:02}:{seconds:02}"
            except Exception:
                total_tat = ''
        entry.entry_total_tat = total_tat
        entry_list.append(entry)

    unique_states = AIS140Request.objects.values_list('state', flat=True).distinct()
    unique_assigned_engineer_email = AIS140Request.objects.values_list('assigned_engineer_email', flat=True).distinct()
    unique_categories = AIS140Request.objects.values_list('category', flat=True).distinct()
    unique_completion_statuses = AIS140Request.objects.values_list('completion_status', flat=True).distinct()

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        table_data = render_to_string(
            'AIS140_FLOW/partials/real_time_table_rows.html',
            {'entries': entry_list}
        )
        return JsonResponse({
            'table_data': table_data,
            'page': paged_entries.number,
            'num_pages': paginator.num_pages,
            'has_next': paged_entries.has_next(),
            'has_previous': paged_entries.has_previous(),
        })
    return render(request, 'AIS140_FLOW/real_time_page.html', {
        'entries': entry_list,
        'unique_states': unique_states,
        'unique_assigned_to': unique_assigned_engineer_email,
        'unique_categories': unique_categories,
        'unique_completion_statuses': unique_completion_statuses,
        'page': paged_entries.number,
        'num_pages': paginator.num_pages,
        'has_next': paged_entries.has_next(),
        'has_previous': paged_entries.has_previous(),
    })
@csrf_exempt
def api_create_ais140_ticket(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body.decode('utf-8'))

            # Required fields from customer payload
            required_fields = [
                'request_date', 'state', 'chassis_number', 'engine_no', 'obu_id', 'vehicle_reg_no',
                'vehicle_model', 'personnel_name', 'mobile_number', 'pan_no', 'aadhar_no', 'mfg_year',
                'rto_name', 'rto_code', 'dealer_name', 'dealer_code', 'ao', 'ro', 'zo', 'sos_confirmed_on'
            ]
            for field in required_fields:
                if field not in data:
                    return JsonResponse({'success': False, 'error': f'Missing field: {field}'}, status=400)

            # Map customer_fields to AIS140Request fields
            entry = AIS140Request.objects.create(
                date_of_request=data.get('request_date'),
                state=data.get('state'),
                vin_no=data.get('chassis_number'),
                engine=data.get('engine_no'),
                psn=data.get('obu_id'),
                vehicle_no=data.get('vehicle_reg_no'),
                vehicle_model=data.get('vehicle_model'),
                customer_name=data.get('personnel_name'),
                customer_phone=data.get('mobile_number'),
                pan_card=data.get('pan_no'),
                aadhar_card=data.get('aadhar_no'),
                manufacturing_year=data.get('mfg_year'),
                rto_name=data.get('rto_name'),
                rto_code=data.get('rto_code'),
                dealer_name=data.get('dealer_name'),
                dealer_code=data.get('dealer_code'),
                ao_name=data.get('ao'),
                ro=data.get('ro'),
                zone=data.get('zo'),
                sos_fitment_date=data.get('sos_confirmed_on'),
            )
            return JsonResponse({'success': True, 'ticket_id': entry.id, 'unique_id': entry.unique_id})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=500)
    else:
        return JsonResponse({'success': False, 'error': 'Only POST allowed'}, status=405)

@require_GET
def fetch_darby_communication_ais140(request, id):
    from django.shortcuts import get_object_or_404
    import requests

    try:
        entry = get_object_or_404(AIS140Request, id=id)
        vin = (getattr(entry, 'vin_no', '') or getattr(entry, 'vin', '')).strip().upper()
        logger.debug("fetch_darby_communication_ais140 - VIN: %s (entry.id=%s)", vin, id)
        if not vin:
            return JsonResponse({'success': False, 'error': 'VIN not available for this entry'}, status=400)

        api_url = "https://api.al.drivewithdarby.com/v1/assets/dynamic/search"
        headers = {
            "Authorization": "Bearer eyJhbGciOiJIUzM4NCJ9.eyJpc3MiOiJkYXJieSIsImp0aSI6ImJkNzVmYWIzLWNhNDktNDBiMi1iZGJjLThiYzJiMDllOTFlNyIsImlhdCI6MTc1MDg0NDc2OSwiZXhwIjoxNzgyMzgwNzY5LCJDSSI6NDIsIlVJIjoiMzFhZmUzMjgtZTIzYS00MDI2LWJkMGEtYmJkMzViMGRkODg0IiwiRU0iOiJWaXNod2FuYXRoLkdAYXNob2tsZXlsYW5kLmNvbSIsIlJJIjoiMWQ5MDllZTUtOWQ1ZS00Y2E3LWJjZmEtMzQ5YWUzM2YzMjIzIiwiVFkiOiJBRE1JTl9VU0VSIiwiRk4iOiJWaXNod2FuYXRoIiwiTE4iOiJHOiBEYW5sYXcgQXNzZXQgRHluYW1pYyBTZWFyY2giLCJQSSI6IjMxYWZlMzI4LWUyM2EtNDAyNi1iZDBhLWJiZDM1YjBkZDg4NCIsIlBOIjoiRGFubGF3IEFzc2V0IER5bmFtaWMgU2VhcmNoIiwiQUkiOiJjOWQ1YjViOS1lNjE4LTQ5OTktYmY1Mi1hNjQ4NTgwYjU0N2EiLCJBVCI6WyJBU1NFVDpSRUFEIiwiUkVQT1JUOlJFQUQiLCJMSVZFOlJFQUQiLCJDQU1QQUlHTjpSRUFEIiwiREFTSEJPQVJEOlJFQUQiXX0.LPPA6mVuKOH1L_KOvoe0r1anfuSMSjbuWyYdK7LVH82UGLKpQpsASMoSEHz81p0L",  # keep token secure
            "Content-Type": "application/json"
        }
        payload = {"assetType": "DEVICE", "filters": {"vin": [vin]}}

        resp = requests.post(api_url, headers=headers, json=payload, timeout=10)
        logger.debug("Darby API status: %s", resp.status_code)
        logger.debug("Darby API body: %s", resp.text)
        resp.raise_for_status()
        data = resp.json()

        # parsing logic (existing)
        candidates = []
        if isinstance(data, dict):
            for key in ('data', 'assets', 'result', 'items'):
                if key in data and isinstance(data[key], list):
                    candidates.extend(data[key])
            if not candidates:
                for v in data.values():
                    if isinstance(v, list):
                        candidates.extend(v)
        elif isinstance(data, list):
            candidates = data

        iccid = ''
        imei = ''
        asset = None
        for item in candidates:
            if isinstance(item, dict) and ('iccid' in item or 'imei' in item):
                asset = item
                break

        if not asset:
            def find_in(obj):
                if isinstance(obj, dict):
                    if 'iccid' in obj or 'imei' in obj:
                        return obj
                    for v in obj.values():
                        res = find_in(v)
                        if res:
                            return res
                if isinstance(obj, list):
                    for el in obj:
                        res = find_in(el)
                        if res:
                            return res
                return None
            asset = find_in(data)

        if asset and isinstance(asset, dict):
            iccid = asset.get('iccid') or asset.get('iccid_no') or asset.get('iccidNumber') or ''
            imei  = asset.get('imei')  or asset.get('imei_no')   or asset.get('imeiNumber')   or ''

        # Always return raw payload for frontend inspection; keep success True so frontend can act
        return JsonResponse({
            'success': True,
            'iccid': iccid or '',
            'imei': imei or '',
            'raw': data
        })
    except requests.RequestException as e:
        logger.error("Darby API request error: %s", e)
        return JsonResponse({'success': False, 'error': f'API request failed: {str(e)}'}, status=502)
    except Exception as e:
        logger.exception("Unexpected error in fetch_darby_communication_ais140")
        return JsonResponse({'success': False, 'error': str(e)}, status=500)