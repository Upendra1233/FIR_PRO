from django import forms
from .models import AIS140Request

class ManagerForm(forms.ModelForm):
    class Meta:
        model = AIS140Request
        fields = [
            'unique_id',
            'date_of_request', 'customer_name', 'customer_phone', 'dealer_name', 'assigned_to',
            'state',  'rto_code', 'rto_name', 'vehicle_available_in_workshop', 'assigned_engineer_email',
            'device_mode', 'request_type', 'vin_no', 'psn', 'aadhar_card', 'teleco_status', 'teleco_type',
            'validity_expiry_date', 'sos_fitment_date', 'pan_card', 'manufacturing_year', 'engine','requested_by',
            'requested_name',
            'requested_phone_number','dealer_code',
            'vehicle_no', 'vehicle_model', 'owner_name', 'owner_phone', 'ao_name', 'ro', 'zone','remarks',
            'completion_status', 'sim_activation_manual', 'sim_activation_service', 'request_sent_by_email'
        ]
        widgets = {
            'date_of_request': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'validity_expiry_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'sos_fitment_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'manufacturing_year': forms.NumberInput(attrs={'min': 1900, 'max': 2100}),
            'sw_flashed_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'remarks': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Enter remarks','rows': 1}),
            'requested_by': forms.Select(attrs={'class': 'form-control'}),
            'requested_name': forms.Select(attrs={'class': 'form-control','placeholder': 'Select Mail ID'}),
            'requested_phone_number': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Phone Number'}),
            'dealer_code': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Dealer Code'}),

        }


class EngineerForm(forms.ModelForm):
    class Meta:
        model = AIS140Request
        fields = [
'unique_id',
            'd1', 'D1_engineer', 'd2', 'D2_engineer', 'd3', 'remarks', 'communication_status', 'vehicle_running_location',
            'contact_person', 'contact_person_phone', 'sw_flashed_version', 'sw_flashed_date', 'sos_verification'
        ]
        widgets = {
            'sw_flashed_date': forms.DateInput(attrs={'type': 'date'}),
        }

    def clean_vehicle_running_location(self):
        value = self.cleaned_data.get('vehicle_running_location')
        if value not in dict(AIS140Request.VEHICLE_RUNNING_LOCATION).keys():
            raise forms.ValidationError("Invalid value for vehicle running location.")
        return value

class PartBForm(forms.ModelForm):
    class Meta:
        model = AIS140Request
        fields = [
            'unique_id',
            'device_mode', 'request_type', 'icicid_no', 'imei_no', 'subscription_raised_by',
            'current_sim_status', 'existing_plan_start_date', 'existing_plan_end_date',
            'reqd_plan_start_date', 'reqd_plan_end_date', 'plan_reqd', 'top_up_reqd_for',
            'sr_req_no', 'sr_req_date', 'sr_success_date', 'tat_sr_s_sr_r', 'existing_sw',
            'sch_sw', 'sw_sch_date', 'sw_success_date', 'tat_sws_swsch', 'veh_status','certification_start_date','certification_end_date',
            'bb_completed_date', 'sos_fitment', 'sos_fitment_date', 'sos_verification_reqd',
            'sos_verified_date', 'data_posting_verification', 'data_verified_date',
            'otp_generated_date', 'otp_updated_date', 'temp_cert_reqd', 'temp_cert_date','permanent_cert_date',
            'permanent_certificate', 'responsibility',  'completion_status', 'completion_date','remarks_02',
            'upload_certificate_in_ialert','upload_certificate_in_ialert_01','upload_certificate_in_ialert_02', 'mail_to_customer','Dealer_mail', 'TSM_mail','upload_certificate_in_danlaw_server',
            'total_tat','d1','d2','D1_engineer', 'D2_engineer'
        ]

        widgets = {
            'device_mode':forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Device Model'}),
            'certification_start_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'certification_end_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'remarks_02' :forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Enter remarks','rows': 1}),
            'existing_plan_start_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'existing_plan_end_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'reqd_plan_start_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'reqd_plan_end_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'sr_req_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'sr_success_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'sw_sch_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'sw_success_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'sos_fitment_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'sos_verified_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'data_verified_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'otp_generated_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'otp_updated_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'temp_cert_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'completion_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'top_up_reqd_for': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter top-up required for','rows': 1}),
            'permanent_cert_date;': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'responsibility': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter responsibility'}),
            'upload_certificate_in_ialert': forms.ClearableFileInput(attrs={'class': 'form-control'}),  # Fixed widget
            'upload_certificate_in_ialert_01': forms.ClearableFileInput(attrs={'class': 'form-control'}),  # Fixed widget
            'upload_certificate_in_ialert_02': forms.ClearableFileInput(attrs={'class': 'form-control'}),  # Fixed widget
            'upload_certificate_in_danlaw_server': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Danlaw server certificate details'}),
            'icicid_no': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter ICICID No', 'maxlength': '20'}),
            'imei_no': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter IMEI No', 'maxlength': '17'}),
            'd1': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter D1 Remarks', 'rows': 1}),
            'd2': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter D2 Remarks', 'rows': 1}),
            'D1_engineer': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter D1 Engineer Email'}),
            'D2_engineer': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter D2 Engineer Email'}),
            'Dealer_mail': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Dealer Mail ID' , 'row': 1}),
            'TSM_mail': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter TSM Mail ID' , 'row': 1}),
            
        }


