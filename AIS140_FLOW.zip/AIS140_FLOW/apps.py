from django.apps import AppConfig


class AIS140FlowConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "AIS140_FLOW"  # Update this to match the app folder name